import java.util.*;
import edu.princeton.cs.algs4.*;

public class FastCollinearPoints {


    private Point[] _points ;
    private ArrayList<LineSegment> segments;
    private int segmentNumber = 0;

    public FastCollinearPoints(Point[] points) {
        // Rescale the coordinate system.
       // StdDraw.setXscale(0, 32768);
       // StdDraw.setYscale(0, 32768);
        // Read points from the input file.

        if(points == null)
            throw new IllegalArgumentException();

        Point last = null  ;
        for (Point p : points) {
            if (p == null)
                throw new IllegalArgumentException();

            if(last != null)
            {
                if(last.compareTo(p) == 0)
                    throw new IllegalArgumentException();
            }
            last = p;
        }

         int pointsCount = points.length;

        _points = points.clone();

        segments = new ArrayList<LineSegment>();


        // Go each point p.
        for (int p = 0; p < pointsCount - 1; p++) {
            // Sort the points according to the slopes they makes with p.
            Arrays.sort(_points,_points[p].slopeOrder());
            // Check if any 3 (or more) adjacent points in the sorted order have equal slopes with respect to p
            ArrayList<Point> collinearPoints = new ArrayList<Point>(pointsCount);
            for (int q = 0; q < pointsCount - 1; q++) {

                if (p == q) {
                    continue;
                }
                if (collinearPoints.isEmpty()) {
                    collinearPoints.add(_points[q]);
                } else if (_points[p].slopeTo(_points[q - 1]) == _points[p].slopeTo(_points[q])) {
                    collinearPoints.add(_points[q]);
                } //else if (collinearPoints.size() > 3) {
                    // Draw collinear points.
                  //  collinearPoints.add(_points[p]);
                  //  Collections.sort(collinearPoints);
                    // Display collinear points.
                    //for (int i = 0; i < 3; i++) {
                    //    StdOut.print(collinearPoints.get(i));
                    //    StdOut.print(" -> ");
                    //}
                  //  StdOut.println(Collections.max(collinearPoints));
                   // Collections.min(collinearPoints).drawTo(Collections.max(collinearPoints));
                   // segments.add(new LineSegment(Collections.min(collinearPoints),Collections.max(collinearPoints))) ;

                   // break;
                //} //else {
                  //  collinearPoints.clear();
                  //  collinearPoints.add(_points[q]);
               // }
            }
            if(collinearPoints.size() > 3)
            {
                segments.add(new LineSegment(Collections.min(collinearPoints),Collections.max(collinearPoints))) ;
            }
            collinearPoints.clear();
        }
    }
    public int numberOfSegments()
    {
        return segments.size();
    }
    public LineSegment[] segments() {

        int size = segments.size();
        LineSegment[] s = new LineSegment[size];
        for(int i = 0 ; i < size;i++)
        {
            s[i] = segments.get(i);
        }
        return s;
    }
}