import edu.princeton.cs.algs4.*;
import java.util.*;

public class BruteCollinearPoints {

    //private Point[] _points ;
    private ArrayList<LineSegment> segments;
    //private int segmentNumber = 0;

    public BruteCollinearPoints(Point[] points)
    {

        if(points == null)
            throw new IllegalArgumentException();

        Point last =null  ;
        for (Point p : points) {
            if (p == null)
                throw new IllegalArgumentException();

            if(last != null)
            {
                if(last.compareTo(p) == 0)
                    throw new IllegalArgumentException();
            }
            last = p;
        }

       Point[] _points = points.clone();
        int N = points.length;
        segments = new ArrayList<LineSegment>();


        Quick.sort(_points);



        for (int p = 0; p < N; p++) {
        for (int q = p+1; q < N; q++) {
            for (int r = q+1; r < N; r++) {
                for (int s = r+1; s < N; s++) {
                    if (_points[p].slopeTo(_points[q]) == _points[p].slopeTo(_points[r]) && _points[p].slopeTo(_points[q]) == _points[p].slopeTo(_points[s])) {
                        //StdOut.println(points[p].toString() + " -> " + points[q].toString() + " -> " + points[r].toString() + " -> " +points[s].toString());
                        //points[p].drawTo(points[s]);
                        LineSegment seg = new LineSegment(_points[p],_points[s]);
                        segments.add(seg) ;
                       // segmentNumber++;
                    }
                }
            }
        }
    }
    }
    public int numberOfSegments()
    {
       return segments.size();
    }
    public LineSegment[] segments() {
        int size = segments.size();
        LineSegment[] s = new LineSegment[size];
        for(int i = 0 ; i < size;i++)
        {
            s[i] = segments.get(i);
        }
        return s;
    }
    public static void main(String[] args) {






    }
}